Find food in North Beach with the help of Alexa.
